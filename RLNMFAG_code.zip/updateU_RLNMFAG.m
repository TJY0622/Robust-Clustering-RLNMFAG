function [Us]=updateU_RLNMFAG(X,U0,V,Y,lambda,epsilon)
F=X*V;
S=U0*diag(sum(V));
first=X*Y*V+lambda*F;
second=U0*(V'*Y*V)+lambda*S;
Us=U0.*first./max(second,epsilon);
end