clc
clear
centerX=3;
centerY=3;
n1=100;
n2=100;
n3=100;
n=n1+n2+n3;
r1=0.16+0.1*rand(n,1);
r2=0.16+0.1*rand(n,1);
r3=0.16+0.1*rand(n,1);
interval=1/27;
the_angle1=(2/3-interval)*pi*rand(n,1);
the_angle2=(2/3-interval)*pi*rand(n,1)+2/3*pi;
the_angle3=(2/3-interval)*pi*rand(n,1)+4/3*pi;
X1=r1.*cos(the_angle1)+centerX;
Y1=r1.*sin(the_angle1)+centerY;
X2=r2.*cos(the_angle2)+centerX;
Y2=r2.*sin(the_angle2)+centerY;
X3=r3.*cos(the_angle3)+centerX;
Y3=r3.*sin(the_angle3)+centerY;
Size=50;

X=[Y1',Y2',Y3',centerY;X1',X2',X3',centerX];
%%
P=7;
XX=X./max(max(X));
distance='squaredeuclidean';
DDv =L2_distance_1(XX,XX);
options = [];
options.WeightMode = 'Binary';  
options.k=P;
Gh = constructW(X',options);
[m,n]=size(X);
DCol = full(sum(Gh,2));
Dh = spdiags(DCol,0,n,n);
s=3;
p=s;


V0=rand(n,p);
U0=rand(m,p);
limiter=1

lambda=10^(-7);alpha=10^(-7);beta=10^(-3);P=7;
[~,S,~]=RLNMFAG(X,U0,V0,DDv,lambda,alpha,beta,limiter,10^-10,P,distance);


name='RLNMFAG';


ll=36;
ll2=144;
[ns2,ms2]=find(S>0);
figure('name',strcat('limit=',num2str(limiter)))
hold on
axis square
box on
for i=1:length(ns2)
    f21=linspace(X(1,ns2(i)),X(1,ms2(i)),3);
    f22=linspace(X(2,ns2(i)),X(2,ms2(i)),3);
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1,Y1,Size,'ro');
p2=scatter(X2,Y2,Size,'bo');
p3=scatter(X3,Y3,Size,'go');
p4=scatter(centerX,centerY,Size,'rp');
h=legend([p1,p2,p3,p4,h1],'data point 1','data point 2','data point 3','outlier',name,'NumColumns',2);
legend('boxoff')
set(h,'FontName','Times New Roman','FontSize',11,'FontWeight','normal')
hold off
%%
limiter=5
lambda=10^(-7);alpha=10^(-7);beta=10^(-3);P=7;
[~,S,~]=RLNMFAG(X,U0,V0,DDv,lambda,alpha,beta,limiter,10^-10,P,distance);
name='RLNMFAG';
[ns2,ms2]=find(S>0);
figure('name',strcat('limit=',num2str(limiter)))
hold on
axis square
box on
for i=1:length(ns2)
    f21=linspace(X(1,ns2(i)),X(1,ms2(i)),3);
    f22=linspace(X(2,ns2(i)),X(2,ms2(i)),3);
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1,Y1,Size,'ro');
p2=scatter(X2,Y2,Size,'bo');
p3=scatter(X3,Y3,Size,'go');
p4=scatter(centerX,centerY,Size,'rp');
h=legend([p1,p2,p3,p4,h1],'data point 1','data point 2','data point 3','outlier',name,'NumColumns',2);
legend('boxoff')
set(h,'FontName','Times New Roman','FontSize',11,'FontWeight','normal')
hold off
%%
limiter=10
lambda=10^(-7);alpha=10^(-7);beta=10^(-3);P=7;
[~,S,~]=RLNMFAG(X,U0,V0,DDv,lambda,alpha,beta,limiter,10^-10,P,distance);
name='RLNMFAG';
[ns2,ms2]=find(S>0);
figure('name',strcat('limit=',num2str(limiter)))
hold on
axis square
box on
for i=1:length(ns2)
    f21=linspace(X(1,ns2(i)),X(1,ms2(i)),3);
    f22=linspace(X(2,ns2(i)),X(2,ms2(i)),3);
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1,Y1,Size,'ro');
p2=scatter(X2,Y2,Size,'bo');
p3=scatter(X3,Y3,Size,'go');
p4=scatter(centerX,centerY,Size,'rp');
h=legend([p1,p2,p3,p4,h1],'data point 1','data point 2','data point 3','outlier',name,'NumColumns',2);
legend('boxoff')
set(h,'FontName','Times New Roman','FontSize',11,'FontWeight','normal')
hold off
%%
S=Gh;
name='k-NN';
[ns2,ms2]=find(S>0);
figure('name','k-NN')
hold on
axis square
box on
for i=1:length(ns2)
    f21=linspace(X(1,ns2(i)),X(1,ms2(i)),3);
    f22=linspace(X(2,ns2(i)),X(2,ms2(i)),3);
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1,Y1,Size,'ro');
p2=scatter(X2,Y2,Size,'bo');
p3=scatter(X3,Y3,Size,'go');
p4=scatter(centerX,centerY,Size,'rp');
h=legend([p1,p2,p3,p4,h1],'data point 1','data point 2','data point 3','outlier',name,'NumColumns',2);
legend('boxoff')
set(h,'FontName','Times New Roman','FontSize',11,'FontWeight','normal')
hold off