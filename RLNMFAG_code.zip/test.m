clc
clear
name={'Yale_32x32','ORL_32x32','JAFFE_Salt_Pepper_noise_0',...%3
    'UMIST_Salt_Pepper_noise_0','2k2k','COIL100',...%6
    'ALOI_100','handwritten','Mfeat'};
name2={'Yale','ORL','JAFFE',...
    'UMIST','MNIST','COIL100',...
    'ALOI 100 ','UCI Handwritten Digits','Mfeat'};
parameter=[
-11,0,-7,8;
-10,0,-6,5;
-10,0,-6,7;%3
-10,2,-5,7;
-11,0,-4,14;
-10,3,-6,10;%6
-11,1,-6,15;
-11,3,0,14;
-9,3,-6,18];%9

iii=7

Selection=name{iii};
if strcmp(Selection,'ALOI_100')
    load(strcat(Selection,'.mat'));
    fea=fea{1,1};
    gnd=gt;
    clear gt
elseif strcmp(Selection,'Mfeat')
    load(strcat(Selection,'.mat'));
    fea=double(data{1,1})';
    gnd=truth;
    clear data per10 per20 per30 per40 per50 per60 per70  truth
elseif strcmp(Selection,'2k2k')
    load('D:\浙大数据集\2k2k.mat')
    clear testIdx trainIdx
elseif strcmp(Selection,'COIL100')
    load('D:\浙大数据集\COIL100.mat')
    fea=double(fea);
else
    load(strcat(Selection,'.mat'));
end
Min=min(min(fea));
if Min<0
   fea=fea-Min;
end
nr=length(unique(gnd));
X=fea';
rX=sum(X,2);
X(rX==0,:)=[];
[m,n]=size(X);
p=nr;
Xv=X./max(max(X));
if strcmp(Selection,'2k2k') 
distance='cosine';
DDh = pdist2(Xv',Xv','cosine'); 
else
distance='squaredeuclidean';
DDh =L2_distance_1(Xv,Xv);
end
limiter=100;
clear Xv fea rX Min
T=10;
ME=zeros(T,2);
epsilon=10^-10;
TimeME=zeros(T,1);
for t=1:T
V0=rand(n,p);
U0=rand(m,p);

    tic
    [U0,S0,V0]=RLNMFAG(X,U0,V0,DDh,10^parameter(iii,1),10^parameter(iii,2),10^parameter(iii,3),limiter,epsilon,parameter(iii,4),distance);
    timeME=toc;
    TimeME(t)=timeME;
    [Accuracy,MIhat] = evalResults(V0',gnd);
    ME(t,:)=[Accuracy,MIhat];
end
result1=[mean(ME,1)';std(ME,0,1)']
mean(TimeME)
