# RLNMFAG
The code of Robust Local-coordinate Non-negative Matrix Factorization with Adaptive Graph for Robust Clustering
INFORMATION SCIENCES, 
under review.
Jiayi Tang and Hui Feng

test.m; robust.m; spatial_structure.m; orthogonality.m;Fig2.m