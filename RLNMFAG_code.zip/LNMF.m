function [U,V]=LNMF(X,U0,V0,lambda,limiter,epsilon)
for iter=1:limiter
    U0=updateU_LNMF(X,U0,V0,lambda,epsilon);
    V0=updateV_LNMF(X,U0,V0,lambda,epsilon);
end
U=U0;
V=V0;
end