clc
clear
n=500;
n_abnormal=150;
k=1/4;
wucha=0.25;
x=linspace(1,10,n);
x=x+wucha*rand(1,n);
y=k*x+wucha*randn(1,n);
x_abnormal=0+10*rand(1,n_abnormal)+wucha*rand(1,n_abnormal);
error=35;
y_abnormal=k*x_abnormal+wucha*rand(1,n_abnormal)+error;
X=[x,x_abnormal];
Y=[y,y_abnormal];
XX=[X;Y];
[mm,nn]=size(XX);
T=20;
K=zeros(T,1);
P=7;
Xv=X./max(max(X));
DDv =L2_distance_1(Xv,Xv);
options.WeightMode = 'Binary'; 
options = [];
options.k=P;
Gh = constructW(X',options);
DCol = full(sum(Gh,2));
Dh = spdiags(DCol,0,nn,nn);
parfor i=1:T
U0=rand(mm,1);
V0=rand(nn,1);
limiter=100;
epsilon=10^-10;

[WMEHx,SMEHx,HMEHx]=RLNMFAG(XX,U0,V0,DDv,10^-11,10^0,10^-6,limiter,epsilon,7,'squaredeuclidean');
K(i)=WMEHx(2)/WMEHx(1);  

end
mean(K)
xplot=0:0.5:11;
figure('name','RLNMFAG')
hold on
grid on
box on
axis([0 11 -1 error+5]) 
h1=scatter(x,y,100,'ko');
h2=scatter(x_abnormal,y_abnormal,100,'rp');
h=plot(xplot,mean(K)*xplot,'--r','LineWidth',2);
legend([h1,h2,h],{'origin data','outliers','curve fitting by RLNMFAG'},'FontSize',12)
hold off