function [Vs]=updateV_LNMF(X,U,V0,lambda,epsilon)
K=X'*X;
a=diag(K);
[N,k]=size(V0);
A=repmat(a,1,k);
B=zeros(N,k);
for i=1:N
    B(i,:)=diag(U'*X(:,i)*ones(1,k));
end
UtU=U'*U;
c=diag(UtU);
C=repmat(c',N,1);
first=2*(X'*U+lambda*B);
second=2*V0*UtU+lambda*(A+C);
Vs=V0.*first./max(second,epsilon);
end