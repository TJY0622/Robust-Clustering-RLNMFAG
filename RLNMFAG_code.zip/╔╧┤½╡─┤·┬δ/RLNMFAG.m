function [U0,G,V0,obj,Result]=RLNMFAG(X,U0,V0,DDv,lambda,alpha,beta,limiter,epsilon,k,distance,Tlabel)
if nargin < 12
    Tlabel = [];
else
    p=length(unique(Tlabel));
end
[~,num]=size(X);
[G,r]=Robust_Adaptive_Graph(DDv,k);
D = diag(sqrt(sum(G)));
G=D\G/D;
GG=sparse(num,num);
G=sparse(G);
D=sparse(1:num,1:num,ones(num,1));
%%
obj=[];
Result=[];
%%
for iter=1:limiter
    Y=X-U0*V0';
    E=sqrt(sum(Y.^2,1));
    Y=max(2*E.*(1+E),epsilon);
    Y=diag(1./Y);
    Y=sparse(Y);
    if ~isempty(Tlabel)
        H=diag(sum(V0,1));
        sumsum=0;
        ccc=size(V0,2);
        for kkk=1:num
            sumsum=sumsum+trace(X(:,kkk)*ones(1,ccc)*diag(V0(kkk,:))*ones(ccc,1)*X(:,kkk)');
        end
        obj= [obj;sum(log(1+E))+alpha*trace(V0'*(D-G)*V0)+lambda*(trace(U0*H*U0'-2*X*V0*U0')+sumsum)];
        Accuracy=0;MIhat=0;
        for k=1:10
            [a,b] = evalResults(V0',Tlabel);
            Accuracy=Accuracy+a;
            MIhat=MIhat+b;
        end
        Result=[Result;Accuracy/10,MIhat/10];
    end
    clear YY E sumsum ccc labelME21_S
    
    V=updateV_RLNMFAG(X,U0,V0,Y,lambda,alpha,G,D,epsilon);
    if norm(V-V0,'fro')<10^-10
        V0=V;
        break
    else
        V0=V; 
    end
    U0=updateU_RLNMFAG(X,U0,V0,Y,lambda,epsilon);
    
    if norm(GG-G,'fro')^2>10^-3
    GG=G;    
    VV=V0./max(max(V0));
    if strcmp(distance,'squaredeuclidean')
        distf =L2_distance_1(VV',VV');
    elseif strcmp(distance,'cosine')
        distf = pdist2(VV,VV,'cosine');
    end
    clear VV
    A = zeros(num);
    for i=1:num
           idxa0 = 1:num;
        dfi = distf(i,idxa0);
        dxi = DDv(i,idxa0);
        ad = -(dxi+beta*dfi)/(2*r);
        A(i,idxa0) = EProjSimplex_new(ad);
    end
    G = (A+A')/2;
    clear A
    D = diag(sum(G));
    G=sparse(G);
    D=sparse(D);
    end
end
end