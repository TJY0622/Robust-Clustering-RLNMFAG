function [Vs]=updateV_RLNMFAG(X,U,V0,Y,lambda,alpha,Gv,Dv,epsilon)
K=X'*X;
b=diag(K);
[n,r]=size(V0);
B=repmat(b,1,r);
WtW=U'*U;
a=diag(WtW);
A=repmat(a',n,1);
first=2*(Y*X'*U+lambda*X'*U+alpha*Gv*V0);
second=2*(Y*V0*WtW+alpha*Dv*V0)+lambda*(A+B);
Vs=V0.*first./max(second,epsilon);
end