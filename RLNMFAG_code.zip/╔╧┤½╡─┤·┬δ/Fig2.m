clc
clear
load('Fig2 Robust  adaptive local structure learning strategy.mat')


figure('name','origin data')
Size=75;
hold on
axis square
box on
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
p3=scatter(outlier(1,1),outlier(1,2),Size,'mp');
h=legend([p1,p2,p3],'data point 1','data point 2','outlier','NumColumns',3);
hold off

X=[X1;X2;outlier]';



Xv=X./255;
% DDv = pdist2(Xv',Xv','squaredeuclidean');
distance='squaredeuclidean';
DDv =L2_distance_1(Xv,Xv);
[m,n]=size(X);
r=2;
k=5;

options = [];
options.WeightMode = 'Binary';  
options.k=k;
G = constructW(X',options);

U0=rand(m,r);
V0=rand(n,r);
limiter=0;
lambda=-100;
alpha=-100;
beta=-100;
P=k+5;
[~,S,~]=RLNMFAG(X,U0,V0,DDv,10^lambda,10^alpha,10^beta,limiter,10^-10,P,distance);
[~, A, ~] = CAN(X, r,P);

S2=full(G);
name='k-NN';
KK=k;
ll=36;
ll2=144;
[ns2,ms2]=find(S2>0);
figure('name','k-NN')
hold on
axis square
box on
for i=1:length(ns2)
    f21=[X(2,ns2(i)),X(2,ms2(i))];
    f22=[X(1,ns2(i)),X(1,ms2(i))];
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
p3=scatter(outlier(1,1),outlier(1,2),Size,'mp');
h=legend([p1,p2,p3,h1],'data point 1','data point 2','outlier',strcat('k-NN,',32,'k=',num2str(KK)),'NumColumns',4);
set(h,'FontSize',11,'FontWeight','normal')
hold off
%%
S2=S;
name='Eq. (3)';
KK=P;
[ns2,ms2]=find(S2>0);
figure('name','ME')
hold on
axis square
box on
for i=1:length(ns2)
    f21=[X(2,ns2(i)),X(2,ms2(i))];
    f22=[X(1,ns2(i)),X(1,ms2(i))];
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
p3=scatter(outlier(1,1),outlier(1,2),Size,'mp');
h=legend([p1,p2,p3,h1],'data point 1','data point 2','outlier',strcat('Eq.(2),',32,'k=',num2str(KK)),'NumColumns',4);
set(h,'FontSize',11,'FontWeight','normal')
hold off
%%
S2=A;
name='CAN';
KK=P;
[ns2,ms2]=find(S2>0);
figure('name','CAN')
hold on
axis square
box on
for i=1:length(ns2)
    f21=[X(2,ns2(i)),X(2,ms2(i))];
    f22=[X(1,ns2(i)),X(1,ms2(i))];
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
p3=scatter(outlier(1,1),outlier(1,2),Size,'mp');
h=legend([p1,p2,p3,h1],'data point 1','data point 2','outlier',strcat('CAN ,',32,'k=10'),'NumColumns',4);
set(h,'FontSize',11,'FontWeight','normal')
hold off