function [Us]=updateU_LNMF(X,U0,V,lambda,epsilon)
[N,k]=size(V);
F=0;
S=0;
for i=1:N
    D=diag(V(i,:));
    F=F+X(:,i)*ones(1,k)*D;
    S=S+U0*D;
end
first=X*V+lambda*F;
second=U0*(V'*V)+lambda*S;
Us=U0.*first./max(second,epsilon);
end