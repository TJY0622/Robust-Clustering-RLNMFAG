clc
clear
x1=6;
y1=9;
n1=200;
r1=0.3;
r2=-0;
X1=[x1*ones(n1,1),y1*ones(n1,1)]+r1*randn(n1,2)+r2;
x2=9;
y2=9;
n2=200;
X2=[x2*ones(n2,1),y2*ones(n2,1)]+r1*randn(n2,2)+r2;
x3=9;
y3=5;
n3=200;
X3=[x3*ones(n3,1),y3*ones(n3,1)]+r1*randn(n3,2)+r2;
X=[X1',X2',X3'];




[m,n]=size(X);
s=3;
P=5;
XX=X./max(max(X));
distance='squaredeuclidean';
DDv =L2_distance_1(XX,XX);
limiter=1000;
p=s;
epsilon=10^-10;
U0=rand(m,p);
V0=rand(n,p);
x0=0:20;
ppp=10;
ks=24;
k=24;
kk=3;
kkk=8;
kkkk=16;


[UL,VL]=LNMF(X,U0,V0,10^0,limiter,10^-10);
VL=VL./repmat(sum(VL,2),1,p);
V_LNMF=ppp*VL'*VL;

yL_1=(UL(2,1)/UL(1,1))*x0;
yL_2=(UL(2,2)/UL(1,2))*x0;
yL_3=(UL(2,3)/UL(1,3))*x0;


lambda=10^(-1);alpha=10^(-2);beta=10^(-3);
[U,S,V]=RLNMFAG(X,U0,V0,DDv,lambda,alpha,beta,limiter,10^-10,P,distance);
V=V./repmat(sum(V,2),1,p);
V_LNMFANHx=ppp*V'*V;
yME_1=(U(2,1)/U(1,1))*x0;
yME_2=(U(2,2)/U(1,2))*x0;
yME_3=(U(2,3)/U(1,3))*x0;






%%
% %LNMF
figure('name','LNMF 1')
hold on
box on
grid on
axis([0 13 0 13])
h1=scatter(X1(:,1),X1(:,2),ks,'ro');
h2=scatter(X2(:,1),X2(:,2),ks,'bo');
h3=scatter(X3(:,1),X3(:,2),ks,'ko');
hL_1=plot(x0,yL_1,'--k','LineWidth',kk,'MarkerSize',kkk);
hL_2=plot(x0,yL_2,'--k','LineWidth',kk,'MarkerSize',kkk);
hL_3=plot(x0,yL_3,'--k','LineWidth',kk,'MarkerSize',kkk);
h=legend([h1,h2,h3,hL_1],'Original data point 1','Original data point 2','Original data point 3','LNMF');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
hold off
%
figure('name','LNMF 2')
hold on
axis([0.5 3.5 0.5 3.5]); 
title(['V^TV obtained by LNMF'],'Fontsize',15);
for i=3:-1:1
    for j=1:3
        scatter(j,i,V_LNMF(4-i,j),'b','filled','s');
    end
end
box on
hold off
%%
%RLNMFAG_Hx
figure('name','RLNMFAG 1')
hold on
box on
grid on
axis([0 13 0 13])
h1=scatter(X1(:,1),X1(:,2),ks,'ro');
h2=scatter(X2(:,1),X2(:,2),ks,'bo');
h3=scatter(X3(:,1),X3(:,2),ks,'ko');
% h4=scatter(X4(:,1),X4(:,2),ks,'ko');
hME_1=plot(x0,yME_1,'--k','LineWidth',kk,'MarkerSize',kkk);
hME_2=plot(x0,yME_2,'--k','LineWidth',kk,'MarkerSize',kkk);
hME_3=plot(x0,yME_3,'--k','LineWidth',kk,'MarkerSize',kkk);
h=legend([h1,h2,h3,hME_1],'Original data point 1','Original data point 2','Original data point 3','RLNMFAG');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
hold off
%
figure('name','RLNMFAG 2')
hold on
axis([0.5 3.5 0.5 3.5]); 
title(['V^TV obtained by RLNMFAG'],'Fontsize',15);
for i=3:-1:1
    for j=1:3
        scatter(j,i,V_LNMFANHx(4-i,j),'b','filled','s');
    end
end
box on
hold off