function [G,eta]=Robust_Adaptive_Graph(D,k)
d=sort(D,2);
dtk=mean(d(:,k+2));
eta=(k*dtk-mean(sum(d(:,2:k+1),2)))/2;
G=max((dtk-D)./(2*eta),0);
end